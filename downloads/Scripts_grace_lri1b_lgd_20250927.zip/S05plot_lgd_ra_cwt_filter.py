from scipy.io import loadmat
from matplotlib import pyplot as plt
import numpy as np
from S02compute_grace_lgd import OrbitLoader
import cartopy.crs as ccrs
import cartopy.feature as cfeature
import os
import matplotlib.ticker as ticker


plt.rcParams['font.sans-serif'] = ['SimHei', 'Microsoft YaHei', 'DejaVu Sans']
plt.rcParams['axes.unicode_minus'] = False

def plot_residual_comparison(date_str, groops_workspace, data_type, trunc_st=None, trunc_ed=None):
    """
    绘制原始信号和小波滤波后信号的对比图

    参数:
    - date_str: 日期字符串，如 '2020-07-07'
    - groops_workspace: GROOPS工作空间路径
    - data_type: 数据类型，'ra' 或 'lgd'
    - trunc_st, trunc_ed: 截取数据的起始和结束索引
    """

    input_dir = os.path.join(groops_workspace, 'results')
    output_dir = os.path.join(groops_workspace, 'results')

    if data_type == 'ra':
        ori_filename = os.path.join(input_dir, f'time-{data_type}-{date_str}.mat')  # 原始数据文件路径
        cwt_filename = os.path.join(input_dir, f'cwt_time-{data_type}-{date_str}.mat')  # 小波重构数据文件路径
        ori_var_name = 'time_ra'
        cwt_var_name = 'cwt_ra'
    elif data_type == 'lgd':
        ori_filename = os.path.join(input_dir, f'time-{data_type}-{date_str}.mat')  # 原始数据文件路径
        cwt_filename = os.path.join(input_dir, f'cwt_time-{data_type}-{date_str}.mat')  # 小波重构数据文件路径
        ori_var_name = 'time_lgd'
        cwt_var_name = 'cwt_lgd'
    else:
        raise ValueError("data_type 必须是 'ra' 或 'lgd'")

    if not os.path.exists(ori_filename):
        raise FileNotFoundError(f"原始数据文件不存在: {ori_filename}")
    if not os.path.exists(cwt_filename):
        raise FileNotFoundError(f"小波滤波数据文件不存在: {cwt_filename}")

    # 加载数据
    ori_data = loadmat(ori_filename)[ori_var_name].astype(np.float64)
    cwt_data = loadmat(cwt_filename)

    # 提取时间序列和信号
    cwt_time = cwt_data['time'].squeeze()   # 当日时间，累积秒，如5、10、15、20、...
    cwt_signal = cwt_data[cwt_var_name].squeeze() * 1e9  # 小波滤波后信号，单位m/s^2 -> nm/s^2

    ori_time = cwt_time
    ori_signal = ori_data[:, 1] * 1e9  # 原始信号，单位m/s^2，单位m/s^2 -> nm/s^2

    # 确保信号长度一致
    min_len = min(len(ori_signal), len(cwt_signal))
    ori_signal = ori_signal[:min_len]
    cwt_signal = cwt_signal[:min_len]
    cwt_time = cwt_time[:min_len]

    # 设置默认截取范围
    if trunc_st is None:
        trunc_st = 0
    if trunc_ed is None:
        trunc_ed = min_len

    # 加载轨道数据
    orbit_loader = OrbitLoader(
        date_str=date_str,
        groops_workspace_output_dir=os.path.join(groops_workspace, "output"))
    orbit_ground = orbit_loader.load_orbit_data('groops_integrated_fit2_dynamicOrbit_ef', 'C', 'geodetic')

    lonlat = np.array([orb.get_geodetic() for orb in orbit_ground])
    apr_lon_array, apr_lat_array = lonlat[:, 0], lonlat[:, 1]

    # 绘图
    fig = plt.figure(figsize=(14, 5))

    # 创建子图布局
    ax1 = plt.subplot2grid((2, 3), (0, 0))
    ax2 = plt.subplot2grid((2, 3), (1, 0))
    ax3 = plt.subplot2grid((2, 3), (0, 1))
    ax4 = plt.subplot2grid((2, 3), (1, 1))
    ax5 = plt.subplot2grid((2, 3), (0, 2))
    # 创建带地图投影的子图
    ax6 = plt.subplot2grid((2, 3), (1, 2), projection=ccrs.PlateCarree())


    # 绘制第（1，1）个子图，origianl residual range_rate-lat
    ax1.scatter(ori_signal[trunc_st: trunc_ed],
                     apr_lat_array[trunc_st: trunc_ed], color='blue', s=1)
    ax1.set_xlabel(f'{data_type.upper()} (nm/s^2)')
    ax1.set_ylabel('latitude (°)')
    ax1.set_title(f'original {data_type.upper()}')
    # ax[0,0].set_xlim(-1e-6, 1e-6)

    # 绘制第（2，1）个子图,original time-residual range_rate
    ax2.scatter(ori_time[trunc_st: trunc_ed],
                     ori_signal[trunc_st: trunc_ed], color='red', s=1)
    ax2.set_xlabel('Time')
    ax2.set_ylabel(f'{data_type.upper()}(nm/s^2)')
    ax2.set_title(f'original {data_type.upper()}')
    # ax2.set_ylim(-1e-6, 1e-6)

    # 绘制第（2，1）个子图，cwt residual range_rate-lat
    ax3.scatter(cwt_signal[trunc_st: trunc_ed],
                     apr_lat_array[trunc_st: trunc_ed], color='blue', s=1)
    ax3.set_xlabel(f'{data_type.upper()} (nm/s^2)')
    ax3.set_ylabel('latitude (°)')
    ax3.set_title(f'cwt {data_type.upper()}')
    ax3.yaxis.set_major_locator(ticker.MultipleLocator(20))  # 每20度一个主刻度
    # ax3.yaxis.set_minor_locator(ticker.MultipleLocator(5))  # 每5度一个次刻度（可选）
    ax3.grid(True, which='major', linestyle='--', alpha=0.7)  # 在主刻度处添加网格线
    # ax3.set_xlim(-1e-6, 1e-6)

    # 绘制第（2，2）个子图,cwt time-residual range_rate
    ax4.scatter(cwt_time[trunc_st: trunc_ed],
                     cwt_signal[trunc_st: trunc_ed], color='red', s=1)
    ax4.set_xlabel('Time')
    ax4.set_ylabel(f'{data_type.upper()}(nm/s^2)')
    ax4.set_title(f'cwt {data_type.upper()}')
    # ax4.set_ylim(-1e3, 1e3)

    # 绘制第（1，3）个子图，卫星轨迹
    ax5.scatter(apr_lon_array[trunc_st: trunc_ed], apr_lat_array[trunc_st: trunc_ed], color='red', s=1)
    ax5.set_xlabel('lon (°)')
    ax5.set_ylabel('lat (°)')
    ax5.set_title('卫星轨迹')

    # 绘制第（1，3）个子图，卫星轨迹
    # 绘制第（2，3）个子图，带地图背景的卫星轨迹
    ax6.add_feature(cfeature.COASTLINE)   # 海岸线
    ax6.add_feature(cfeature.BORDERS)     # 国界
    ax6.add_feature(cfeature.LAND, facecolor='lightgray')  # 陆地
    ax6.add_feature(cfeature.OCEAN, facecolor='lightblue') # 海洋

    # 绘制选定段的轨道
    ax6.plot(apr_lon_array, apr_lat_array,
             color='blue', linewidth=1.5, marker='.', markersize=2,
             transform=ccrs.PlateCarree(), label='All orbit')
    ax6.plot(apr_lon_array[trunc_st: trunc_ed], apr_lat_array[trunc_st: trunc_ed],
             color='red', linewidth=1.5, marker='.', markersize=2,
             transform=ccrs.PlateCarree(), label='Selected orbit segment')

    # 设置地图显示范围（根据选定段的经纬度动态调整）
    # margin = 5  # 边界留白度数
    # ax6.set_extent([np.min(apr_lon_array) - margin,
    #                 np.max(apr_lon_array) + margin,
    #                 np.min(apr_lat_array) - margin,
    #                 np.max(apr_lat_array) + margin],
    #                crs=ccrs.PlateCarree())

    ax6.set_title('卫星轨迹')
    plt.tight_layout()
    plt.savefig(os.path.join(output_dir, f'{data_type}_comparison_{date_str}.png'),
                dpi=300, bbox_inches='tight',
                facecolor='white', edgecolor='none')
    plt.show()

if __name__ == '__main__':
    date_str = '2020-07-07'
    groops_workspace = 'G:\GROOPS\dynamicOrbitSolutionWorkspaceLRI'
    data_type = 'lgd'  # 'ra' 或 'lgd'

    # trunc_st, trunc_ed = 10280, 10480   # 2021-07-20
    trunc_st, trunc_ed = 13675, 14975  # 2020-07-07
    # trunc_st, trunc_ed = 0, 17280
    plot_residual_comparison(date_str, groops_workspace, data_type, trunc_st, trunc_ed)



