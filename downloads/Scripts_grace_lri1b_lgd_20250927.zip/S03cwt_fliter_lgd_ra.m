clear;clc;

date_str = '2020-07-07';
data_type = 'lgd';  % 'lgd' or 'ra'
process_cwt_fliter_signal_data(date_str, data_type);